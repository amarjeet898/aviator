
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                    <i class="mdi mdi-home"></i>
                </span> Change Password
            </h3>
            
        </div>
        <div class="row">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Change Password</h4>
                    <form class="forms-sample" id="changepassword">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="userid" value="<?php echo e(admin('id')); ?>">
                      <div class="form-group">
                        <label for="exampleInputName1">New Password</label>
                        <input type="password" class="form-control" id="newpassword" name="newpassword" placeholder="New password">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Re type Password</label>
                        <input type="password" class="form-control" id="renewpassword" name="renewpassword" placeholder="Re enter New password">
                      </div>
                      <button type="submit" class="btn btn-gradient-primary me-2">Submit</button>
                    </form>
                  </div>
                </div>
              </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $("#changepassword").on('submit', function(e) {
            e.preventDefault();
        });
        $("#changepassword").validate({
            submitHandler: function(form) {
                apex("POST", "<?php echo e(url('admin/api/changepassword')); ?>", new FormData(form), form, "/admin/dashboard", "#");
            }
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seekosoft/adbanao.seekosoft.com/laravel/resources/views/admin/changepassword.blade.php ENDPATH**/ ?>