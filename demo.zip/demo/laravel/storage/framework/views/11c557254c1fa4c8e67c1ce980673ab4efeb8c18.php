
<?php $__env->startSection('content'); ?>
    <div class="active" id="via-email">
        <form class="register-form row w-25" style="margin: 100px auto 0 auto; color: white !important;"
            action="/wallet_transfer" method="post" id="amounttransfer">
            <h2><?php echo e($title); ?></h2>
            <?php echo csrf_field(); ?>
            <div class="col-md-12 col-12">
                <div class="input-group flex-nowrap mb-3 promocode align-items-center">
                    <span class="input-group-text" id="addon-wrapping">
                        <span class="material-symbols-outlined bold-icon">
                            badge
                        </span>
                    </span>
                    <input type="text" class="form-control ps-0" id="userid" placeholder="User Id" name="userid">
                </div>
            </div>
            <div class="col-12">
                <div class="input-group flex-nowrap mb-3 promocode align-items-center">
                    <span class="input-group-text" id="addon-wrapping">
                        <span class="material-symbols-outlined bold-icon">
                            money
                        </span>
                    </span>
                    <input type="number" class="form-control ps-0" id="amount" placeholder="Amount" name="amount">
                </div>
            </div>
            <div class="col-12">
                <label for="promo_code" id="promo_code_error" class="error"></label>
            </div>
            <button type="submit" class="btn orange-btn md-btn custm-btn-2 mx-auto mt-3 mb-0 registerSubmit">Transfer Now</button>

        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
   setInterval(() => {
                                    $.ajax({
                                        url: '/game-cron',
                                        type: "GET",
                                        dataType: "json",
                                        success: function(intialData) {}
                                    });
                                }, 1000);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.usergame2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seekosoft/adbanao.seekosoft.com/laravel/resources/views/amount_transfer.blade.php ENDPATH**/ ?>