
<?php $__env->startSection('css'); ?>
    <style>
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="deposite-container">
        <div class="sub-header">
            <h2 class="head_title">Transaction history</h2>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 mt-md-4 mb-4">
                    <div class="custom-accordian">
                        

                        <div class="tab-content">
                            <div id="deposit_list" class="tab-pane fade in active">
                                <div class="accordian-body">
                                    <div class="profile-row">
                                        <div class="Profile_column">
                                            <div class="acc-row">
                                                
                                                <div class="table-responsive">
                                                    <table id="deposit_report" class="table display nowrap w-100 "
                                                        cellspacing="0" width="100%">
                                                        <thead>
                                                            <tr>
                                                                <th>#</th>
                                                                <th>Payment Gateway Type</th>
                                                                <th>Amount</th>
                                                                <th>Category </th>
                                                                <th>Type </th>
                                                                <th>Remark </th>
                                                                <th>Status</th>
                                                                <th>Requested Date</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php if(count($deposit) > 0): ?>
                                                                <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($loop->iteration); ?></td>
                                                                        <td><?php echo e(ucfirst($item->platform)); ?></td>
                                                                        <td>₹<?php echo e(number_format($item->amount,2)); ?></td>
                                                                        <td><?php echo e(ucfirst($item->category)); ?></td>
                                                                        <td><?php echo e(ucfirst($item->type)); ?></td>
                                                                        <td><?php echo e($item->remark); ?></td>
                                                                        <td>
                                                                            <div class="btn btn-<?php echo e(status($item->status,'recharge')['color']); ?>"><?php echo e(status($item->status,'recharge')['name']); ?></div>
                                                                        </td>
                                                                        <td><?php echo e(dformat($item->created_at,'d-m-Y h:i:s')); ?></td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                                <tr>
                                                                    <td colspan="5" style="text-align: center;">No data
                                                                        found!!</td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('#withdraw_report').DataTable({});
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.usergame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seekosoft/adbanao.seekosoft.com/laravel/resources/views/deposit_withdrawals.blade.php ENDPATH**/ ?>